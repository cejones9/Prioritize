package com.seniorproject.prioritize;

import android.app.AlarmManager;
import android.graphics.Typeface;
import android.icu.util.Calendar;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

public class SetAlarm extends AppCompatActivity {

    AlarmManager alarm_Manager;
    TimePicker alarm_TimePicker;
    DatePicker alarm_DatePicker;
    TextView alarm_TextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_alarm);

        //center align the app title
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar_layout);

        //title font
        Typeface myfont = Typeface.createFromAsset(getAssets(), "Pacifico.ttf");
        TextView app_title = (TextView) findViewById(R.id.mytitle);
        app_title.setTypeface(myfont);

        //initialize alarmmanager
        alarm_Manager = (AlarmManager) getSystemService(ALARM_SERVICE);

        //initialize textview
        alarm_TextView = (TextView) findViewById(R.id.alarmsave_TextView);

        //initialize timepicker
        alarm_TimePicker = (TimePicker) findViewById(R.id.timePicker);

        //initialize datepicker
        alarm_DatePicker = (DatePicker) findViewById(R.id.datePicker);

        //create an instance of a calendar
        final Calendar calendar = Calendar.getInstance();

        //initialize button
        Button save_Alarm = (Button) findViewById(R.id.alarmSave);

        //onClick method for saving the alarm
        save_Alarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calendar.set(Calendar.HOUR_OF_DAY, alarm_TimePicker.getHour());
                calendar.set(Calendar.MINUTE, alarm_TimePicker.getMinute());
                calendar.set(Calendar.YEAR, alarm_DatePicker.getYear());
                calendar.set(Calendar.MONTH, alarm_DatePicker.getMonth());
                calendar.set(Calendar.DAY_OF_MONTH, alarm_DatePicker.getDayOfMonth());

                //get the int values
                int hour, minute, year, month, day;
                hour = alarm_TimePicker.getHour();
                minute = alarm_TimePicker.getMinute();
                year = alarm_DatePicker.getYear();
                month = alarm_DatePicker.getMonth() + 1;
                day = alarm_DatePicker.getDayOfMonth();

                //convert int values to strings
                String hour_string, minute_string, year_string, month_string, day_string;
                hour_string = String.valueOf(hour);
                minute_string = String.valueOf(minute);
                year_string = String.valueOf(year);
                month_string = String.valueOf(month);
                day_string = String.valueOf(day);


                alarm_TextView.setText("Alarm set to: " + "\n" + hour_string + ":" + minute_string + "\n" + month_string + ":" + day_string + ":" + year_string);

            }
        });



    }
}
